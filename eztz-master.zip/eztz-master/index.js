module.exports = require('./src/main')
